#Product Manager v2.0

##Implement the following functionality

###
3. Add category 
4. Add product to category
5. List categories




